const express = require("express");
require('dotenv').config()
const app = express()
const port = 3500
require("./database/db")
const bodyParser = require('body-parser');
const appRoute = require('./Router/route');
const conversationRoutes = require("./Router/conversationRoute")



app.use(bodyParser.urlencoded({
    extended: false
}))
app.use(bodyParser.json())
// app.use(express.urlencoded({ extended: false }))
app.use('/', appRoute)

app.use("/", conversationRoutes)



app.listen(port, () => {
    console.log(`listening to the port no ${port}`)
})

