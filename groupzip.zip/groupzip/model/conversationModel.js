const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");



const ConversationModel = sequelize.define('chatapp_conversationModel', {
    // Model attributes are defined here
    name : {
        type: DataTypes.STRING,
        defaultValue: 'chat'
    },
    isGroupChat : {
        type: DataTypes.BOOLEAN,
        defaultValue : false
    }
});

module.exports = ConversationModel;