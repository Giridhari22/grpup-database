const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");
const UserModel = require('./userModel');
const ConversationModel = require('./conversationModel');



const convUserModel = sequelize.define('chatapp_convUserModel', {
    // Model attributes are defined here
    userId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: UserModel,
            key: 'id'
        }
    },
    ConversationId: {
        type: DataTypes.INTEGER,
        refrences: {
            model: ConversationModel,
            key: 'id'
        }
    }
});

ConversationModel.belongsToMany(UserModel, {
    through: {
        model: UserModel
    },
    foreignKey: 'ConversationId '
})

UserModel.belongsToMany(ConversationModel, {
    through: {
        model: ConversationModel
    },
    foreignKey: 'userId'
})

module.exports = convUserModel;